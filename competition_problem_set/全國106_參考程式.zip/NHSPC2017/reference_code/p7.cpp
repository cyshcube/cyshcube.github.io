#include<cstdio>
#include<cstring>
#include<deque>
#include<vector>
#include<algorithm>
using namespace std;
const int INF=1<<15;
char s[INF], t[INF];

int main()
{
    int N;
    
    //for(scanf("%d", &N); N>0; N--)
    {
        int l, k;
        scanf("%s%s%d%d", s+1, t+1, &l, &k);
        int n=strlen(s+1);
        int m=strlen(t+1);
        
        if( n>m )
        {
            swap(s, t);
            swap(n, m);
        }
        
        vector<deque<pair<int, int>>> dq(m+1);
        vector<int> d(m+1, INF);
        
        for(int i=1; i<=n; i++)
        {
            vector<int> p(m+1, INF);
            deque<pair<int, int>> DQ;
            
            for(int j=max(i-k*l, 1); j<=min(i+k*l, m); j++)
            {
                if( s[i]==t[j] )
                    p[j]=min(d[j-1], (i+l-2)/l+(j+l-2)/l);
                
                while( !dq[j].empty() && i-dq[j].front().second>l )
                    dq[j].pop_front();
                
                while( !DQ.empty() && j-DQ.front().second>l )
                    DQ.pop_front();
                
                if( !dq[j].empty() )
                    p[j]=min(p[j], dq[j].front().first+1);
                
                if( !DQ.empty() )
                    p[j]=min(p[j], DQ.front().first+1);
                
                while( !dq[j].empty() && dq[j].back().first>=p[j] )
                    dq[j].pop_back();
                
                while( !DQ.empty() && DQ.back().first>=p[j] )
                    DQ.pop_back();
                
                if( p[j]>k )
                    p[j]=INF;
                
                dq[j].push_back({p[j], i});
                DQ.push_back({p[j], j});
            }
            
            swap(d, p);
        }
        
        printf(d[m]>k ? "Impossible\n" : "%d\n", d[m]);
    }
}
