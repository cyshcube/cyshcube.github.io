/* maximum total weight of k segments of an array
merge approach
1. first transform to alternating array +-+-+, and we need only the absolute values
The sum of all the positive runs is the solution for k=num of pos runs
2. each iteration find the solution of k--:
2.1 pick the minimum i and merge {pre(i),i,next(i)}
2.2 the resulting weight=pre(i).w - i.w +next(i).w. And the total weight is reduced by i.w

THIS is an O(n) approach.
keep the solution of i runs, initially i=n/2;
tbr=i-k;
choose the tbr-th smallest element p and merge all elements<=p;
if (merge too few) then
    do the rest
else {
    merge all element<p;
    the rest to be merged must =p;
}

Be careful that the merging order of elements in one iteration (need a stack-like DS)

*/

#include<bits/stdc++.h>
using namespace std;

#define N 2000010
#define oo 1<<30
//#define CHECK

int w[2][N];
int n,k;

// input and transform to alternating
// seg[0] and seg[n-1] are dummy and never chosen
void inp() {
    int i,j,s,t,x1,x2;
    scanf("%d%d",&n,&k); //fprintf(stderr,"n=%d, k=%d\n",n,k);//assert(n<=100000);
    w[0][0]=oo;j=-1;
    scanf("%d",&x1);
    for (i=1,t=0;i<n;i++) {
        scanf("%d",&x2); //assert(x2>0 && x2<10000000);
        s=x2-x1;
        if (s*j>=0) w[0][t]+=abs(s);
        else {
            w[0][++t]=abs(s);
            j=-j;
        }
        x1=x2;
    }
    if (j>0) n=t+1;
    else n=t;
    w[0][n++]=oo;
    //assert(n%2==1);
    return;
}
void solve() {
    int i,j,maxw=0,top;
    int s,t,eps;

    inp();
    int tbr=n/2-k; // num of run to be reduced
    for (i=1;i<n;i+=2) maxw+=w[0][i];
    if (tbr<=0) {
        printf("%d\n",maxw);
        return;
    }
    int from=0, to=1,run,cost,times=0;
    while (tbr>0) {
        //times++;
        w[to][0]=oo; top=0;
        run=0; cost=0;
        vector<int> tem (w[from]+1,w[from]+n);
        //fprintf(stderr,"size=%d;",tem.size());
        nth_element(tem.begin(),tem.begin()+tbr-1,tem.end());
        eps=tem[tbr-1];
        for (i=1;i<n && run<= tbr;i++) {
            w[to][++top]=w[from][i];
            while (run<=tbr && top>1 && w[to][top-1]<=eps && w[to][top]>=w[to][top-1]) {
                w[to][top-2]+=w[to][top]-w[to][top-1];
                cost+=w[to][top-1];
                top-=2;
                run++;
            }
        }
        // merge too few
        if (run<=tbr) {
            tbr-=run;
            maxw-=cost;
            n=top+1;
            swap(from,to);
            continue;
        }
        // merge too many;
        eps--;cost=run=0;
        for (i=1;i<n && run<= tbr;i++) {
            w[to][++top]=w[from][i];
            while (top>1 && w[to][top-1]<=eps && w[to][top]>=w[to][top-1]) {
                w[to][top-2]+=w[to][top]-w[to][top-1];
                cost+=w[to][top-1];
                top-=2;
                run++;
            }
        }
        tbr-=run;
        maxw-=cost;
        eps++;
        break;
    }
    //printf("iter=%d,tbr=%d\n",times,tbr);
    printf("%d\n",maxw-tbr*eps);

}

int main() {
#ifdef CHECK
    int tcase;
    char fname[30]="ai_4_01.in",fout[30]="ai_3_01.out";
	for (tcase=1;tcase<10;tcase++) {
        fname[6]='0'+tcase;
        if (freopen(fname,"r",stdin)==NULL) break;
        fout[6]='0'+tcase;
        //freopen(fout,"w",stdout);
        solve();
//return 0;
	}
#else
    solve();
#endif
    return 0;
}

