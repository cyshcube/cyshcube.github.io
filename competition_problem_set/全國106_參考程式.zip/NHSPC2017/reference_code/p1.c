#include <stdio.h>

int main () {
	int ts, n, i, tmp;
	
	scanf("%d", &n);

	int max = 0, min = 2e9;
	for ( i = 0; i < n; i++) {
		scanf("%d", &tmp);
		
		min = (min > tmp)? tmp: min;
		max = (max > tmp)? max: tmp;
		
	}

	printf("%d %d %s\n", min, max, (max-min+1 == n)? "yes": "no");
	
	return 0;
}