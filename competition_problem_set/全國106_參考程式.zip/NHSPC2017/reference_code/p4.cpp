#include<cstdio>
#include<queue>
#include<vector>
using namespace std;
const int INF=1<<20;

struct HK{
	int n, m;
	vector<int> d, p;
	vector<vector<int>> e;
	HK(int _n, int _m) : n(_n), m(_m), e(n+m+1){}
	void add(int u, int v){//one base index: [1, u]*[1, v]
		e[u].push_back(n+v);
		e[n+v].push_back(u);
	}
	bool bfs(){
		d.assign(n+m+1, INF);
		queue<int> Q;
		for(int i=1; i<=n; i++)
			if( p[i]==0 ){
				d[i]=0;
				Q.push(i);
			}
		for(; !Q.empty(); Q.pop()){
			int u=Q.front();
			if( d[u]>d[0] ) break;
			for(int v : e[u])
				if( d[ p[v] ]==INF ){
					d[ p[v] ]=d[u]+1;
					Q.push(p[v]);
				}
		}
		return d[0]<INF;
	}
	bool dfs(int u){
		if( u==0 ) return true;
		for(int v : e[u])
			if( d[ p[v] ]==d[u]+1 && dfs(p[v]) ){
				p[v]=u, p[u]=v;
				return true;
			}
		d[u]=INF;
		return false;
	}
	int operator()(){
		int ans=0;
		p.assign(n+m+1, 0);
		while( bfs() )
			for(int i=1; i<=n; i++)
				if( p[i]==0 && dfs(i) )
					ans++;
		return ans;
	}
};

int main()
{
    int N;
    
    for(scanf("%d", &N); N>0; N--)
    {
        int n, m, k;
        scanf("%d%d%d", &n, &m, &k);
        HK hk(n, m);
        
        for(; k>0; k--)
        {
            int u, v;
            scanf("%d%d", &u, &v);
            hk.add(u, v);
        }
        
        printf("%d\n", hk());
    }
}

/*

10

4 8 5
1 6
1 2
1 8
1 7
4 5

9 9 11
7 8
8 3
8 9
6 1
6 3
2 6
2 4
4 4
4 9
3 6
3 2

10 7 7
5 7
5 6
10 2
4 7
4 6
3 3
6 1

8 3 1
1 1

8 8 6
4 1
7 1
1 8
2 6
2 8
3 8

8 3 3
1 3
5 1
8 2

3 4 5
1 2
1 3
2 1
2 3
3 4

2 5 2
2 4
1 4

7 7 4
6 7
2 4
2 3
4 7

8 2 1
5 2

*/
