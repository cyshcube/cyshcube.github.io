#include<stdio.h>
#include<string.h>

int main()
{
	char n[9];
	int b, d;
	scanf("%d%s",&b,n);
	d = strlen(n);
	int x = 0, y = 0;
	for(int i = 0; n[i]; i++)
	{
		int p = 1;
		for(int j = 0; j < d; j++)
			p *= n[i]-'0';
		x += p;
		y *= b;
		y += n[i]-'0';
	}
	puts(x==y?"YES":"NO");
	return 0;
}
