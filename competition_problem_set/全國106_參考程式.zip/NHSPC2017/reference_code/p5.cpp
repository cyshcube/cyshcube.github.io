#include<cstdio>
#include<queue>
#include<vector>
#include<algorithm>
using namespace std;
const int INF=1<<20;

int next()
{
    int ans=0, tmp;
    while( (tmp=getchar()) && (tmp<'0' || tmp>'9') );
    
    do{
        ans=(ans<<3)+(ans<<1)+(tmp-'0');
    }while( (tmp=getchar()) && ('0'<=tmp && tmp<='9') );
    
    return ans;
}

struct ds
{
    vector<int> p, s;
    ds(int n) : p(n+1, -1), s(n+1, 1){}
    
    int find(int x)
    {
        return p[x]<0 ? x : p[x]=find(p[x]);
    }
    
    int join(int x, int y)
    {
        x=find(x);
        y=find(y);
        
        if( x==y )
            return s[y];
        else if( s[x]>s[y] )
            swap(x, y);
        
        p[x]=y;
        s[y]+=s[x];
        return s[y];
    }
};

int main()
{
    int n=next(), m=next(), ans=0;
    vector<vector<int>> e(n+1);
    vector<int> d(n+1, 0);
    
    for(; m>0; m--)
    {
        int u=next(), v=next();
        e[u].push_back(v);
        e[v].push_back(u);
        d[u]++, d[v]++;
    }
    
    vector<pair<int, int>> o;
    
    for(queue<int> Q; ; )
    {
        int k=INF;
        
        for(int i=1; i<=n; i++)
            if( d[i]>0 )
                k=min(k, d[i]);
        
        if( k>=INF )
            break;
        
        for(int i=1; i<=n; i++)
            if( d[i]==k )
            {
                Q.push(i);
                d[i]=-1;
            }
        
        for(; !Q.empty(); Q.pop())
        {
            int u=Q.front();
            o.push_back({u, k});
            
            for(int v : e[u])
                if( d[v]>0 && --d[v]<=k )
                {
                    Q.push(v);
                    d[v]=-1;
                }
        }
    }
    
    ds S(n);
    
    for(int i=o.size()-1; i>=0; i--)
    {
        int u=o[i].first;
        d[u]=1;
        
        for(int v : e[u])
            if( d[v]>0 )
                ans=max(ans, S.join(u, v)*o[i].second);
    }
    
    printf("%d\n", ans);
}
