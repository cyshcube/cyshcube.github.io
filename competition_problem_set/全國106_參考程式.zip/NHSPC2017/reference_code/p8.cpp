#include<bits/stdc++.h>

using namespace std;

double PI = acos(-1.0);

double tri_area(double a, double b, double c)
{
	double s = (a+b+c)/2;
	return sqrt(s*(s-a)*(s-b)*(s-c));
}

vector<double> a;
double M;

double pred1(double r)
{
	double ret = -PI;
	for(auto x: a)
		ret += asin(0.5*x/r);
	return ret;
}

double pred2(double r)
{
	double ret = 2*asin(0.5*M/r);
	for(auto x: a)
		ret -= asin(0.5*x/r);
	return ret;
}

typedef double (*PRED)(double);

double bisect(double low, double up, PRED pred, double err)
{
	while((up-low)/max(1.0,(up+low))>0.5*err)
	{
		double mid = 0.5*(up+low);
		if(pred(mid)>=0)
			low = mid;
		else
			up = mid;
	}
	return 0.5*(low+up);
}

int main()
{
	int n, k;
	scanf("%d%d",&n,&k);
	vector<double> x(n);
	for(int i = 0; i < n; i++)
		scanf("%lf",&x[i]);
	double best_area=0, best_r;
	int best_idx;
	vector<double> best_angles;
	for(int i = (1<<k)-1; i < (1<<n); i++)
	{
		if(__builtin_popcount(i)!=k) continue;
		a.clear();
		for(int j = 0; j < n; j++)
		{
			if(i&(1<<j))
				a.push_back(x[j]);
		}
		M = 0;
		double sum = 0;
		for(double y: a)
		{
			M = max(y,M);
			sum += y;
		}
		if(M+M > sum) continue;
		double angle_sum = 0, r, area=0, U=1e6;
		vector<double> angles;
		for(double y: a)
			angle_sum+=asin(y/M);
		if(angle_sum>=PI)
		{
			r = bisect(M/2, U, pred1, 1e-12);
			for(double y: a)
			{
				area+=tri_area(r,r,y);
				angles.push_back(2*asin(0.5*y/r));
			}
		}
		else
		{
			r = bisect(M/2, U, pred2, 1e-12);
			area = -2*tri_area(r,r,M);
			for(double y: a)
			{
				area+=tri_area(r,r,y);
				angles.push_back(2*asin(0.5*y/r));
			}
			int Mi=0;
			while(a[Mi]!=M) Mi++;
			angles[Mi]=2*PI-angles[Mi];
		}
		if(area>best_area)
		{
			best_area = area;
			best_r = r;
			best_idx = i;
			best_angles.clear();
			best_angles.push_back(0.0);
			for(double y: angles)
				best_angles.push_back(best_angles.back()+y);
			for(double& y: best_angles)
				y *= 2*PI/best_angles.back();
		}
	}
	for(int i = 0; i < k; i++)
		printf("%.30f %.30f\n",best_r*sin(best_angles[i]),best_r*cos(best_angles[i]));
	int cnt = 0;
	for(int i = 0; i < n; i++)
		if((1<<i) & best_idx)
			printf("%d%c",i+1,++cnt==k?'\n':' ');
	//fprintf(stderr,"%.30f\n",best_area);
	return 0;
}
