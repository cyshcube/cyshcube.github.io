#!/usr/bin/env python3

n = int(input())
cnt = [[0]*8 for _ in range(3)]
while True:
    try:
        t,x,y,z=[int(_) for _ in input().strip().split()]
        cnt[t-1][x+x+x+x+y+y+z] += 1
    except:
        break

ans = 0
for i in range(8):
    for j in range(8):
        for k in range(8):
            if (i|j|k)==7:
                ans += cnt[0][i]*cnt[1][j]*cnt[2][k]
print(ans)
